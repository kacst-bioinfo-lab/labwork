use strict;

# Echo input to output.
while(my $fred = <STDIN>) {
    print $fred;
}
