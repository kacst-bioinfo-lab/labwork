# Prints the message using two different delimeters.
print "Hello, Bioinformatics Guys!\n";
print qq=Did you say "Hello?"\n=;


