# Simple hash constructs
#Variables whose names begin with % are hashes, which are essentially arrays subscripted by strings.


# Initializer for %yard.
%yard = ( red => 'brick',
	  blue => 'sky',
	  green => 'grass',
	  yellow => 'dandelion' );
print "$yard{'blue'} $yard{'yellow'}\n";
