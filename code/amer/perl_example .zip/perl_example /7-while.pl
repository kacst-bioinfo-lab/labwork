use strict;

my $a = 5;
while($a > 0) {
    print "$a ";
    $a--;
}
print "\n";
