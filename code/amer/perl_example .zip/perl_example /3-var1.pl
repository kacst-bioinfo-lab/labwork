# Various operations on scalar (string) variables.
$temp = "we Love perl!";
$barney = 56;
$sum = 10 + $barney;
print 'The variable $temp' . " contains $temp.\n";

print "Sum is $sum.\n";

