# Simple array constructs.

#Variables whose names begin with @ are arrays. If @sue is an array, it is different variable from $sue. However, members of @sue are selected by $sue[$i].

#The construction $#arrname gives the maximum subscript of the array @arrname.

@array = ("How", "are", "you", "today?");
print "\@array contains (@array).\n";

$element = $array[1];
print "$element $array[3]\n";

# The array name in a scalar context gives the size.
$arraysize = @array;
print '@arry has ', "$arraysize elements\n";

# The $#name gives the max subscript (size less one).
print "Max sub is $#array\n";

