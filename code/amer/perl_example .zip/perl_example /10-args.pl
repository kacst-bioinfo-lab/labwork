use strict;


# Perl has a special array called @ARGV . This is the list of arguments passed along with the script name on the command line. Run the following perl script as: perl myscript.pl hello world how are you

# This script simply prints its command line arguments, one per line.
# Perl command line args and the @ARGV array

my $sub = 0;
while($sub <= $#ARGV) {
    print "$ARGV[$sub]\n";
    ++$sub;
}
print "[@ARGV]\n";



