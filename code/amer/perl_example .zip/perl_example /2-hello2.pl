# Shows how single quotes differ from double quotes used in hello.pl
print 'Greetings, small planet!\n';
print q/What's cooking?\n/;


print qq/What's cooking?\n/;
